Research active: selected eight closed-source map references only.
Queue: com.google.android.apps.maps, com.waze, com.tomtom.speedcams.android.map, com.here.app.maps, com.mapswithme.maps.pro, com.generalmagic.magicearth, com.sygic.aura, ru.yandex.yandexmaps
Current: Google Maps. Three agents plus working supervisor. Preserve inputs, Vela and CairoDrive. Previous outputs deleted; rebuild evidence from original APKs. No app changes/builds.
Track exact unit counts and lists for extraction, recovery, semantic analysis, failures and remaining work. Repair and verify errors. Supervisor must exhaust useful cloud work and verify residual limits before advancing. Hourly resume automation enabled; reconcile active jobs before starting any duplicate. Save checkpoints before interruption.
