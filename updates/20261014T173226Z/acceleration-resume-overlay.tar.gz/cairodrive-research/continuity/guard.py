#!/usr/bin/env python3
"""Second local layer: restore a missing watchdog, never duplicate its lock."""
import fcntl,json,os,pathlib,subprocess,time
p=pathlib.Path('/workspace/cairodrive-research/continuity');lock=(p/'guard.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:raise SystemExit(0)
(p/'guard.pid').write_text(str(os.getpid()))
while not (p/'stop-watchdog').exists():
 probe=(p/'watchdog.lock').open('a');restart=False
 try:fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB);restart=True
 except BlockingIOError:pass
 finally:probe.close()
 if restart:
  with (p/'watchdog.log').open('a') as out:
   child=subprocess.Popen(['python3',str(p/'watchdog.py')],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  (p/'guard-last-restart.json').write_text(json.dumps({'new_pid':child.pid,'at':time.time()})+'\n')
 (p/'guard-status.json').write_text(json.dumps({'pid':os.getpid(),'updated':time.time(),'watchdog_restarted':restart})+'\n');time.sleep(15)
