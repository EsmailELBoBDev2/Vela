#!/usr/bin/env python3
import pathlib,fcntl,subprocess,time,os,json
p=pathlib.Path('/workspace/cairodrive-research/continuity');lock=(p/'checkpoint-loop.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:raise SystemExit(0)
(p/'checkpoint-loop.pid').write_text(str(os.getpid()))
while not (p/'stop-watchdog').exists():
 result=subprocess.run(['python3',str(p/'snapshot.py')],capture_output=True,text=True)
 (p/'checkpoint-loop-status.json').write_text(json.dumps({'pid':os.getpid(),'updated':time.time(),'exit':result.returncode,'result':result.stdout.strip(),'error':result.stderr[-500:]})+'\n')
 for _ in range(60):
  if (p/'stop-watchdog').exists():break
  time.sleep(10)
