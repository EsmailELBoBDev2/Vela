#!/usr/bin/env python3
import fcntl,json,pathlib,subprocess,time,os
root=pathlib.Path('/workspace/cairodrive-research');state=root/'continuity';lock=(state/'watchdog.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:raise SystemExit(0)
(state/'watchdog.pid').write_text(str(os.getpid()))
def status(value,**extra):(state/'watchdog-status.json').write_text(json.dumps({'pid':os.getpid(),'status':value,'updated':time.time(),**extra})+'\n')
while not (state/'stop-watchdog').exists():
 try:
  goal=json.loads((root/'GOAL.json').read_text())
  if goal['research_status'] in ['complete','stopped','stopped_waiting_app_selection']:status('paused_by_goal')
  elif not (state/'standalone-enabled').exists():status('disarmed')
  else:
   child=subprocess.Popen(['python3',str(state/'worker.py')],cwd=root)
   while child.poll() is None:
    status('running_iteration',worker_pid=child.pid);time.sleep(5)
   status('iteration_finished',exit_code=child.returncode)
 except Exception as e:status('runtime_error',error=str(e))
 for _ in range(12):
  if (state/'stop-watchdog').exists():break
  time.sleep(5)
status('stopped')
