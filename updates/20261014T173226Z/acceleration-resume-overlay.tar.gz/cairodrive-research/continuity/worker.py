#!/usr/bin/env python3
"""Authenticated research iteration with bounded output writes and single-worker lock."""
import argparse,fcntl,json,os,pathlib,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('--root',default='/workspace/cairodrive-research');p.add_argument('--codex',default='codex');p.add_argument('--check',action='store_true');a=p.parse_args();root=pathlib.Path(a.root);state=root/'continuity';lock=(state/'worker.lock').open('a')
try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:print('Existing worker owns the lock.');sys.exit(0)
g=json.loads((root/'GOAL.json').read_text());package=g['current_package'];selected=g['selected_packages']
if package not in selected or '/' in package:raise SystemExit('Invalid current app; fail closed.')
if a.check:print(json.dumps({'package':package,'scope':'current app outputs + research scratch/continuity only','lock':'acquired'}));sys.exit(0)
if g['research_status'] in ['complete','stopped','stopped_waiting_app_selection'] or not (state/'standalone-enabled').exists():sys.exit(0)
cwd=root/'apps'/package;cwd.mkdir(parents=True,exist_ok=True);scratch=root/'work';scratch.mkdir(exist_ok=True)
args=[a.codex,'exec','--skip-git-repo-check','--sandbox','workspace-write','-c','approval_policy="never"','-c',f'sqlite_home="{state}/state"','-c',f'log_dir="{state}/logs"','--add-dir',str(scratch),'--add-dir',str(state),'-C',str(cwd),'--json']
session=state/'research-thread.json'
if session.exists():
 data=json.loads(session.read_text())
 if data.get('package')==package:args+=['resume',data['thread_id']]
args+=[(state/'resume-prompt.txt').read_text()]
log=state/('run-'+str(time.time_ns())+'.jsonl');start=time.time()
with log.open('w') as out:
 child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=out,text=True)
 (state/'worker-active.json').write_text(json.dumps({'worker_pid':os.getpid(),'codex_pid':child.pid,'package':package,'log':str(log),'started':start,'command':args[:-1]},indent=2)+'\n')
 for line in child.stdout:
  out.write(line);out.flush()
  try:
   e=json.loads(line)
   if e.get('type')=='thread.started':session.write_text(json.dumps({'thread_id':e['thread_id'],'package':package})+'\n')
  except (json.JSONDecodeError,KeyError):pass
 code=child.wait()
(state/'last-run.json').write_text(json.dumps({'exit_code':code,'log':str(log),'finished_at':time.time(),'duration_seconds':time.time()-start},indent=2)+'\n')
sys.exit(code)
